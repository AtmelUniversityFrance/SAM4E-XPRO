Filelist:
SAM4E_Xplained_Pro_design_documentation_release_rev3.pdf : Design Documentation
BOM\Bill of Materials Print- SAM4E_Xplained_Pro_release_rev3.xls : BOM, fitted components
BOM\Bill of Materials SAM4E_Xplained_Pro_release_rev3.txt : BOM for PLM upload
ExportSTEP\SAM4E_Xplained_Pro_release_rev3.step : 3D Model of PCBA
Gerber\SAM4E_Xplained_Pro_release_rev3.GTL : Gerber files for Top Layer LF-signals
Gerber\SAM4E_Xplained_Pro_release_rev3.G1 : Gerber files for MidLayer1
Gerber\SAM4E_Xplained_Pro_release_rev3.G2 : Gerber files for MidLayer2
Gerber\SAM4E_Xplained_Pro_release_rev3.GM1 : Gerber files for Mechanical 1
Gerber\SAM4E_Xplained_Pro_release_rev3.GTP : Gerber files for Top Paste
Gerber\SAM4E_Xplained_Pro_release_rev3.GTO : Gerber files for Top Overlay
Gerber\SAM4E_Xplained_Pro_release_rev3.GTS : Gerber files for Top Solder
Gerber\SAM4E_Xplained_Pro_release_rev3.GP1 : Gerber files for GND
Gerber\SAM4E_Xplained_Pro_release_rev3.GP2 : Gerber files for POWER
Gerber\SAM4E_Xplained_Pro_release_rev3.GBO : Gerber files for Bottom Overlay
Gerber\SAM4E_Xplained_Pro_release_rev3.GBL : Gerber files for Bottom Layer LF-signals
Gerber\SAM4E_Xplained_Pro_release_rev3.GBS : Gerber files for Bottom Solder
Gerber\SAM4E_Xplained_Pro_release_rev3.GBP : Gerber files for Bottom Paste
NC Drill\SAM4E_Xplained_Pro_release_rev3.txt : Drill files, ASCII
NC Drill\SAM4E_Xplained_Pro_release_rev3.drl : Drill files, gerber
NC Drill\SAM4E_Xplained_Pro_release_rev3.drr : Drill files, report
ODB\SAM4E_Xplained_Pro_release_rev3.zip : ODB++ Files
Pick Place\Pick Place for SAM4E_Xplained_Pro_release_rev3.txt : Pick and Place file, component placement
Test Points\Assembly Testpoint Report for SAM4E_Xplained_Pro_release_rev3.txt : Assembly Testpoint report, txt
Test Points\Assembly Testpoint Report for SAM4E_Xplained_Pro_release_rev3.csv : Assembly Testpoint report, csv
